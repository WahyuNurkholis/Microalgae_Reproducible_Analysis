
PLSR per-PBR-type error analysis
================================
Input predictions: /mnt/data/PLSR_environment_error_analysis/PLSR_predictions_with_environment_errors.csv
Model context: PLSR fixed 3 components, leave-one-batch-out validation, image-level average of 4 ROI.
PBR labels: Flat -> FPPBR; Tube -> TPBR.
Targets: OD665, OD750

Output files:
- PLSR_per_PBR_type_error_metrics.csv: Main metrics by PBR type and target.
- PLSR_per_PBR_type_by_environment_metrics.csv: Metrics by PBR type, environment, and target.
- PLSR_per_PBR_type_paired_abs_error_tests.csv: Paired tests comparing absolute error between FPPBR and TPBR at matched Batch x Environment x Day.
- PLSR_per_PBR_type_paired_abs_error_details.csv: Matched pair error details.
- PLSR_predictions_with_PBR_type_errors.csv: All predictions with residual and error columns.
- PNG/SVG figures: true-vs-predicted plots, absolute error boxplots, residual plots, and metric summary plots.

Interpretation guide:
Use absolute error and normalized error together. A smaller absolute error does not always mean a more robust model if the observed OD range is narrower. R2 within subgroup may become negative when the model does not explain within-subgroup variation better than the subgroup mean.
