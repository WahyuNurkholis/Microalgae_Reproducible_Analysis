PLSR Green + Variability curated feature-set analysis

Input file: /mnt/data/microalgae_pbr_image_level_features.csv
Main dataset: image-level average from 4 ROIs per image.
Number of observations: 60 image-level rows.
Validation: leave-one-batch-out cross-validation using Batch parsed from image filenames.
Targets: OD750 and OD665.
Day, image size, OD values, Specific GR, and ROI_Selection_Score were not used as model inputs.

Feature sets:
- Full_features: all numeric image-derived features except metadata, targets, day, and ROI_Selection_Score.
- Color_mean_only: averaged color features only, excluding SD-based features.
- Green_only: green-focused averaged features.
- Green_plus_variability: green-focused averaged features plus within-ROI and among-ROI variability features.

The green + variability set was designed to test whether greenness plus optical/color heterogeneity can improve OD estimation.
Files included:
- curated_feature_set_model_summary.csv
- curated_feature_set_fold_metrics.csv
- curated_feature_set_predictions.csv
- green_variability_inner_tuning_results.csv
- feature_sets_used.csv
- PLSR_green_variability_VIP_coefficients_OD750.csv
- PLSR_green_variability_VIP_coefficients_OD665.csv
- true_vs_pred plots, residual plots, and VIP plots in PNG/SVG.
