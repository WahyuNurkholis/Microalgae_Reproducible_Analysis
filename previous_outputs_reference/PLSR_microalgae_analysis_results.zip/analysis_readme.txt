Microalgae PBR image-feature dataset curation and PLSR analysis
Image-level rows: 60
ROI-level rows: 240
ROI per image: {4: 60}
Balanced batches/PBR/environment/day layout: {('B1', 'Flat', 'Indoor'): 5, ('B1', 'Flat', 'Outdoor'): 5, ('B1', 'Tube', 'Indoor'): 5, ('B1', 'Tube', 'Outdoor'): 5, ('B2', 'Flat', 'Indoor'): 5, ('B2', 'Flat', 'Outdoor'): 5, ('B2', 'Tube', 'Indoor'): 5, ('B2', 'Tube', 'Outdoor'): 5, ('B3', 'Flat', 'Indoor'): 5, ('B3', 'Flat', 'Outdoor'): 5, ('B3', 'Tube', 'Indoor'): 5, ('B3', 'Tube', 'Outdoor'): 5}
Days: {0: 12, 2: 12, 4: 12, 6: 12, 8: 12}
Primary curated features: 32 features = core color means + within-ROI pixel variability
Excluded from ML input: Image name, image size, day, batch, environment, PBR type, OD665, OD750, Specific GR, ROI selection score, ROI-level rows as independent samples.
Main validation: leave-one-batch-out cross-validation. Three batches were used as grouping variable to avoid leakage across cultivation batches.
Main model: PLSR with 3 components, selected from LOBO component curve.

OD750: R2=0.708, RMSE=0.203, MAE=0.163, n=60.
OD665: R2=0.703, RMSE=0.241, MAE=0.190, n=60.