
SVR microalgae image-based OD analysis
======================================
Input file: /mnt/data/microalgae_pbr_image_level_features.csv
Observations: 60 image-level samples.
Validation: nested leave-one-batch-out cross-validation.
Groups: Batch parsed from image filename (B1, B2, B3).
Targets: OD750 and OD665.
Main input features: image-level features averaged from 4 ROI per image, plus optional 4-ROI SD features.
Excluded from input: Day, OD values, Specific GR, image size, ROI size, ROI_Selection_Score.

Important interpretation:
SVR is used as a non-linear benchmark model. It should be compared against PLSR, which remains more interpretable for small datasets with collinear color features.
Permutation importance is supplementary only and was calculated on the final fitted model, not as the main validation result.
