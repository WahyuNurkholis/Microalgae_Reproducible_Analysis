PLSR Residual Analysis
Input: PLSR_fixed3_LOBO_predictions.csv
Validation: leave-one-batch-out. Residual = Observed - Predicted.
Positive residual indicates model underprediction. Negative residual indicates model overprediction.

Overall metrics:
Target    n  Observed_mean  Observed_min  Observed_max  Predicted_mean  Bias_mean_residual  Residual_SD      MAE     RMSE  Max_Abs_Error  NRMSE_by_mean_percent  NMAE_by_mean_percent  MAPE_percent       R2  Spearman_residual_vs_predicted_r  Spearman_residual_vs_predicted_p
 OD665 60.0       0.525133         0.027         1.416        0.526261           -0.001127     0.242636 0.189709 0.240608       0.758014              45.818504             36.125873     92.334528 0.703090                         -0.092581                          0.481707
 OD750 60.0       0.443750         0.025         1.196        0.441959            0.001791     0.204226 0.162839 0.202525       0.567563              45.639511             36.696166     96.332501 0.707942                         -0.089636                          0.495818

Absolute error group tests:
Target    Grouping                               Test  Statistic  p_value
 OD665       Batch                     Kruskal-Wallis   1.288852 0.524964
 OD665 Environment Mann-Whitney U (Indoor vs Outdoor) 628.000000 0.008684
 OD665    PBR type     Mann-Whitney U (FPPBR vs TPBR) 356.000000 0.166866
 OD750       Batch                     Kruskal-Wallis   0.777377 0.677945
 OD750 Environment Mann-Whitney U (Indoor vs Outdoor) 606.000000 0.021506
 OD750    PBR type     Mann-Whitney U (FPPBR vs TPBR) 365.000000 0.211561