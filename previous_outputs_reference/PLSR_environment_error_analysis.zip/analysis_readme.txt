Per-environment error analysis for PLSR fixed 3-component model.
Model predictions are from leave-one-batch-out validation using image-level average of 4 ROI.
Input features are core color + within-ROI variability. Day and ROI_Selection_Score were not used as model inputs.
Residual = observed - predicted. Error = predicted - observed.
R2 within environment is descriptive and should be interpreted with n=30 per environment per target.
